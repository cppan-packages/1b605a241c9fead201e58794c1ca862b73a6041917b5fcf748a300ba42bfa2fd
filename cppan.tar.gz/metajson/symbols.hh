#pragma once
#include <iod/symbol/symbol.hh>

namespace iod
{
  IOD_SYMBOL(name)
  IOD_SYMBOL(type)
  IOD_SYMBOL(json_key)
}
